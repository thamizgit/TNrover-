import React from 'react';
import Navbar from './Navbar';
import MaduraiMap from "./MaduraiMap";
function Madurai(){
    return(
        <div>
            <Navbar/>
            <MaduraiMap/>
            
        </div>
    );
}
export default Madurai;