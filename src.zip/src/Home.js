import React from 'react';
import  Navbar from './Navbar';
import  Cities from './Cities';
function Home() {
  return (
<div>
    <Navbar/>
    <Cities/>
</div>
  );
}

export default Home;
