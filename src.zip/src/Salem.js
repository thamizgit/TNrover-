import React from "react";

import Navbar from './Navbar';
import Map_salem from "./Map_salem";
function Salem(){
    return(
        <div>
            <Navbar/>
            <Map_salem/>
            
        </div>
    );
}
export default Salem;