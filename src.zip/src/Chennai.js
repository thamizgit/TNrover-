import React from "react";

import Navbar from './Navbar';
import Map from './Map';
function Chennai(){
    return(
        <div>
            <Navbar/>
            <Map/>
            
        </div>
    );
}
export default Chennai;